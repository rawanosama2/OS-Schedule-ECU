import sys
import random
import numpy as np
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QComboBox, QTableWidget, QTableWidgetItem, QSpinBox,
    QMessageBox, QFileDialog, QTabWidget, QTextEdit
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

class ProcessGenerator(QWidget):
    def _init_(self):
        super()._init_()
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Title
        title = QLabel("Process Generator Module")
        title.setFont(QFont('Arial', 14, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # Parameters
        params_layout = QHBoxLayout()
        
        left_params = QVBoxLayout()
        self.num_processes = QSpinBox()
        self.num_processes.setRange(1, 100)
        self.num_processes.setValue(10)
        left_params.addWidget(QLabel("Number of Processes:"))
        left_params.addWidget(self.num_processes)
        
        self.arrival_mean = QSpinBox()
        self.arrival_mean.setRange(0, 100)
        self.arrival_mean.setValue(5)
        left_params.addWidget(QLabel("Arrival Time Mean:"))
        left_params.addWidget(self.arrival_mean)
        
        right_params = QVBoxLayout()
        self.burst_mean = QSpinBox()
        self.burst_mean.setRange(1, 100)
        self.burst_mean.setValue(10)
        right_params.addWidget(QLabel("Burst Time Mean:"))
        right_params.addWidget(self.burst_mean)
        
        self.priority_lambda = QSpinBox()
        self.priority_lambda.setRange(1, 10)
        self.priority_lambda.setValue(3)
        right_params.addWidget(QLabel("Priority Lambda:"))
        right_params.addWidget(self.priority_lambda)
        
        params_layout.addLayout(left_params)
        params_layout.addLayout(right_params)
        layout.addLayout(params_layout)
        
        # Buttons
        btn_layout = QHBoxLayout()
        self.generate_btn = QPushButton("Generate Processes")
        self.generate_btn.clicked.connect(self.generate_processes)
        self.save_btn = QPushButton("Save to File")
        self.save_btn.clicked.connect(self.save_to_file)
        btn_layout.addWidget(self.generate_btn)
        btn_layout.addWidget(self.save_btn)
        layout.addLayout(btn_layout)
        
        # Results Table
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["PID", "Arrival", "Burst", "Priority"])
        layout.addWidget(self.table)
        
        self.setLayout(layout)
    
    def generate_processes(self):
        n = self.num_processes.value()
        arrival_mean = self.arrival_mean.value()
        burst_mean = self.burst_mean.value()
        priority_lambda = self.priority_lambda.value()
        
        # Generate arrival times (normal distribution)
        arrival_times = np.abs(np.random.normal(arrival_mean, arrival_mean/2, n)).astype(int)
        arrival_times = np.cumsum(arrival_times)
        
        # Generate burst times (normal distribution)
        burst_times = np.abs(np.random.normal(burst_mean, burst_mean/2, n)).astype(int)
        burst_times = np.where(burst_times < 1, 1, burst_times)  # Ensure minimum burst of 1
        
        # Generate priorities (Poisson distribution)
        priorities = np.random.poisson(priority_lambda, n)
        priorities = np.where(priorities < 1, 1, priorities)  # Ensure minimum priority of 1
        
        # Populate table
        self.table.setRowCount(n)
        for i in range(n):
            self.table.setItem(i, 0, QTableWidgetItem(f"P{i+1}"))
            self.table.setItem(i, 1, QTableWidgetItem(str(arrival_times[i])))
            self.table.setItem(i, 2, QTableWidgetItem(str(burst_times[i])))
            self.table.setItem(i, 3, QTableWidgetItem(str(priorities[i])))
    
    def save_to_file(self):
        filename, _ = QFileDialog.getSaveFileName(self, "Save Processes", "", "Text Files (*.txt)")
        if filename:
            with open(filename, 'w') as f:
                f.write("PID,Arrival,Burst,Priority\n")
                for row in range(self.table.rowCount()):
                    pid = self.table.item(row, 0).text()
                    arrival = self.table.item(row, 1).text()
                    burst = self.table.item(row, 2).text()
                    priority = self.table.item(row, 3).text()
                    f.write(f"{pid},{arrival},{burst},{priority}\n")
            QMessageBox.information(self, "Success", "Processes saved to file successfully!")

class SchedulerGUI(QWidget):
    def _init_(self):
        super()._init_()
        self.processes = []
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Title
        title = QLabel("CPU Scheduling Simulator")
        title.setFont(QFont('Arial', 14, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # File Input
        file_layout = QHBoxLayout()
        self.file_btn = QPushButton("Load Processes")
        self.file_btn.clicked.connect(self.load_processes)
        self.file_label = QLabel("No file loaded")
        file_layout.addWidget(self.file_btn)
        file_layout.addWidget(self.file_label)
        layout.addLayout(file_layout)
        
        # Algorithm Selection
        algo_layout = QHBoxLayout()
        algo_layout.addWidget(QLabel("Scheduling Algorithm:"))
        
        self.algo_combo = QComboBox()
        self.algo_combo.addItems([
            "First Come First Serve (FCFS)",
            "Non-Preemptive Highest Priority First (HPF)",
            "Round Robin (RR)",
            "Preemptive Shortest Remaining Time First (SRTF)"
        ])
        algo_layout.addWidget(self.algo_combo)
        
        # Time Quantum (for RR)
        self.tq_label = QLabel("Time Quantum:")
        self.time_quantum = QSpinBox()
        self.time_quantum.setRange(1, 100)
        self.time_quantum.setValue(4)
        self.tq_label.hide()
        self.time_quantum.hide()
        algo_layout.addWidget(self.tq_label)
        algo_layout.addWidget(self.time_quantum)
        
        self.algo_combo.currentTextChanged.connect(self.toggle_time_quantum)
        layout.addLayout(algo_layout)
        
        # Run Button
        self.run_btn = QPushButton("Run Scheduling")
        self.run_btn.setStyleSheet("background-color: #4CAF50; color: white;")
        self.run_btn.clicked.connect(self.run_scheduler)
        layout.addWidget(self.run_btn)
        
        # Results Tabs
        self.tabs = QTabWidget()
        
        # Process Table Tab
        self.process_tab = QWidget()
        self.process_table = QTableWidget()
        self.process_table.setColumnCount(4)
        self.process_table.setHorizontalHeaderLabels(["PID", "Arrival", "Burst", "Priority"])
        process_layout = QVBoxLayout()
        process_layout.addWidget(self.process_table)
        self.process_tab.setLayout(process_layout)
        self.tabs.addTab(self.process_tab, "Input Processes")
        
        # Results Table Tab
        self.results_tab = QWidget()
        self.results_table = QTableWidget()
        self.results_table.setColumnCount(7)
        self.results_table.setHorizontalHeaderLabels([
            "PID", "Arrival", "Burst", "Priority", 
            "Start", "Finish", "Waiting", "Turnaround"
        ])
        results_layout = QVBoxLayout()
        results_layout.addWidget(self.results_table)
        self.results_tab.setLayout(results_layout)
        self.tabs.addTab(self.results_tab, "Scheduling Results")
        
        # Gantt Chart Tab
        self.gantt_tab = QWidget()
        self.gantt_text = QTextEdit()
        self.gantt_text.setReadOnly(True)
        gantt_layout = QVBoxLayout()
        gantt_layout.addWidget(self.gantt_text)
        self.gantt_tab.setLayout(gantt_layout)
        self.tabs.addTab(self.gantt_tab, "Gantt Chart")
        
        # Statistics Tab
        self.stats_tab = QWidget()
        self.stats_text = QTextEdit()
        self.stats_text.setReadOnly(True)
        stats_layout = QVBoxLayout()
        stats_layout.addWidget(self.stats_text)
        self.stats_tab.setLayout(stats_layout)
        self.tabs.addTab(self.stats_tab, "Statistics")
        
        layout.addWidget(self.tabs)
        self.setLayout(layout)
    
    def toggle_time_quantum(self, text):
        if "Round Robin" in text:
            self.tq_label.show()
            self.time_quantum.show()
        else:
            self.tq_label.hide()
            self.time_quantum.hide()
    
    def load_processes(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Load Processes", "", "Text Files (*.txt)")
        if filename:
            self.file_label.setText(filename)
            self.processes = []
            
            with open(filename, 'r') as f:
                lines = f.readlines()
                # Skip header if exists
                start = 1 if lines[0].startswith("PID") else 0
                
                self.process_table.setRowCount(len(lines) - start)
                for i, line in enumerate(lines[start:]):
                    parts = line.strip().split(',')
                    pid = parts[0]
                    arrival = int(parts[1])
                    burst = int(parts[2])
                    priority = int(parts[3]) if len(parts) > 3 else 1
                    
                    self.processes.append({
                        'pid': pid,
                        'arrival': arrival,
                        'burst': burst,
                        'priority': priority,
                        'remaining': burst,
                        'start': -1,
                        'finish': -1,
                        'waiting': 0,
                        'turnaround': 0
                    })
                    
                    self.process_table.setItem(i, 0, QTableWidgetItem(pid))
                    self.process_table.setItem(i, 1, QTableWidgetItem(str(arrival)))
                    self.process_table.setItem(i, 2, QTableWidgetItem(str(burst)))
                    self.process_table.setItem(i, 3, QTableWidgetItem(str(priority))))
    
    def run_scheduler(self):
        if not self.processes:
            QMessageBox.warning(self, "Error", "No processes loaded!")
            return
        
        algo = self.algo_combo.currentText()
        
        try:
            if "FCFS" in algo:
                results, gantt = self.run_fcfs()
            elif "HPF" in algo:
                results, gantt = self.run_hpf()
            elif "RR" in algo:
                tq = self.time_quantum.value()
                results, gantt = self.run_rr(tq)
            elif "SRTF" in algo:
                results, gantt = self.run_srtf()
            
            self.display_results(results, gantt)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")
    
    def run_fcfs(self):
        """First Come First Serve (non-preemptive)"""
        processes = sorted(self.processes, key=lambda x: x['arrival'])
        current_time = 0
        gantt = []
        
        for p in processes:
            p['start'] = max(current_time, p['arrival'])
            p['finish'] = p['start'] + p['burst']
            p['waiting'] = p['start'] - p['arrival']
            p['turnaround'] = p['finish'] - p['arrival']
            current_time = p['finish']
            
            gantt.append((p['pid'], p['start'], p['finish']))
        
        return processes, gantt
    
    def run_hpf(self):
        """Non-Preemptive Highest Priority First"""
        processes = sorted(self.processes, key=lambda x: (x['priority'], x['arrival']))
        current_time = 0
        gantt = []
        
        while any(p['finish'] == -1 for p in processes):
            ready = [p for p in processes if p['arrival'] <= current_time and p['finish'] == -1]
            
            if not ready:
                current_time += 1
                continue
            
            # Select process with highest priority (lowest number)
            selected = min(ready, key=lambda x: x['priority'])
            selected['start'] = current_time
            selected['finish'] = current_time + selected['burst']
            selected['waiting'] = selected['start'] - selected['arrival']
            selected['turnaround'] = selected['finish'] - selected['arrival']
            
            gantt.append((selected['pid'], selected['start'], selected['finish']))
            current_time = selected['finish']
        
        return processes, gantt
    
    def run_rr(self, time_quantum):
        """Round Robin (preemptive)"""
        from collections import deque
        
        processes = sorted(self.processes, key=lambda x: x['arrival'])
        queue = deque()
        current_time = 0
        completed = 0
        n = len(processes)
        gantt = []
        
        # Reset remaining time
        for p in processes:
            p['remaining'] = p['burst']
            p['start'] = -1
            p['finish'] = -1
        
        while completed < n:
            # Add arriving processes to queue
            for p in processes:
                if p['arrival'] == current_time:
                    queue.append(p)
            
            if not queue:
                current_time += 1
                continue
            
            current_process = queue.popleft()
            
            # Mark start time if this is first run
            if current_process['start'] == -1:
                current_process['start'] = current_time
            
            # Execute for time quantum or remaining time
            exec_time = min(time_quantum, current_process['remaining'])
            gantt.append((current_process['pid'], current_time, current_time + exec_time))
            
            current_process['remaining'] -= exec_time
            current_time += exec_time
            
            # Check if process completed
            if current_process['remaining'] == 0:
                current_process['finish'] = current_time
                current_process['turnaround'] = current_process['finish'] - current_process['arrival']
                current_process['waiting'] = current_process['turnaround'] - current_process['burst']
                completed += 1
            else:
                # Re-add to queue if not finished
                queue.append(current_process)
        
        return processes, gantt
    
    def run_srtf(self):
        """Shortest Remaining Time First (preemptive)"""
        processes = sorted(self.processes, key=lambda x: x['arrival'])
        current_time = 0
        completed = 0
        n = len(processes)
        gantt = []
        last_pid = None
        
        # Reset remaining time
        for p in processes:
            p['remaining'] = p['burst']
            p['start'] = -1
            p['finish'] = -1
        
        while completed < n:
            # Find process with shortest remaining time
            ready = [p for p in processes 
                    if p['arrival'] <= current_time and p['remaining'] > 0]
            
            if not ready:
                current_time += 1
                continue
            
            shortest = min(ready, key=lambda x: x['remaining'])
            
            # Mark start time if this is first run
            if shortest['start'] == -1:
                shortest['start'] = current_time
            
            # Execute for 1 time unit
            shortest['remaining'] -= 1
            current_time += 1
            
            # Update Gantt chart
            if gantt and gantt[-1][0] == shortest['pid']:
                # Extend last block
                gantt[-1] = (shortest['pid'], gantt[-1][1], current_time)
            else:
                # New block
                gantt.append((shortest['pid'], current_time - 1, current_time))
            
            # Check if process completed
            if shortest['remaining'] == 0:
                shortest['finish'] = current_time
                shortest['turnaround'] = shortest['finish'] - shortest['arrival']
                shortest['waiting'] = shortest['turnaround'] - shortest['burst']
                completed += 1
        
        return processes, gantt
    
    def display_results(self, results, gantt):
        # Update results table
        self.results_table.setRowCount(len(results))
        for i, p in enumerate(results):
            self.results_table.setItem(i, 0, QTableWidgetItem(p['pid']))
            self.results_table.setItem(i, 1, QTableWidgetItem(str(p['arrival'])))
            self.results_table.setItem(i, 2, QTableWidgetItem(str(p['burst'])))
            self.results_table.setItem(i, 3, QTableWidgetItem(str(p['priority'])))
            self.results_table.setItem(i, 4, QTableWidgetItem(str(p['start'])))
            self.results_table.setItem(i, 5, QTableWidgetItem(str(p['finish'])))
            self.results_table.setItem(i, 6, QTableWidgetItem(str(p['waiting'])))
            self.results_table.setItem(i, 7, QTableWidgetItem(str(p['turnaround'])))
        
        # Generate Gantt chart text
        gantt_text = "Gantt Chart:\n"
        for pid, start, end in gantt:
            duration = end - start
            gantt_text += f"[{pid}] {start}-{end} {'='*duration}\n"
        self.gantt_text.setPlainText(gantt_text)
        
        # Calculate statistics
        avg_wait = sum(p['waiting'] for p in results) / len(results)
        avg_turnaround = sum(p['turnaround'] for p in results) / len(results)
        
        stats_text = f"""
        Scheduling Algorithm: {self.algo_combo.currentText()}
        
        Average Waiting Time: {avg_wait:.2f}
        Average Turnaround Time: {avg_turnaround:.2f}
        
        Individual Process Results:
        """
        for p in results:
            stats_text += f"\n{p['pid']}: Waiting={p['waiting']}, Turnaround={p['turnaround']}"
        
        self.stats_text.setPlainText(stats_text)
        
        # Switch to results tab
        self.tabs.setCurrentIndex(1)

class MainWindow(QMainWindow):
    def _init_(self):
        super()._init_()
        self.setWindowTitle("CPU Scheduling Simulator")
        self.setGeometry(100, 100, 1000, 700)
        
        # Create tabs
        self.tabs = QTabWidget()
        self.process_gen_tab = ProcessGenerator()
        self.scheduler_tab = SchedulerGUI()
        
        self.tabs.addTab(self.process_gen_tab, "Process Generator")
        self.tabs.addTab(self.scheduler_tab, "CPU Scheduler")
        
        self.setCentralWidget(self.tabs)

if _name_ == "_main_":
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
